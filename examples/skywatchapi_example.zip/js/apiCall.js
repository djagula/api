"use strict"

function init() {
 $.ajax({
        //API URL
        url: 'https://api.skywatch.co/data/time/2015/location/36.281389,-80.060278/level/3',
      
        dataType: 'json',
        method: 'GET',
        beforeSend: function(xhr) {
             xhr.setRequestHeader('x-api-key', "xxxxxxxxxxxxxxxxxxxxxx");
        },
         success: function(data){
            console.log(data);
            document.querySelector("#response").innerHTML = JSON.stringify(data);
        }
      })
};

window.onload = init;
